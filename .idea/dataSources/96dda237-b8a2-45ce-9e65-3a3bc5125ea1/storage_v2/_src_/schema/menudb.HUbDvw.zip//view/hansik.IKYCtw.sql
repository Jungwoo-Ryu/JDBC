create definer = ohgiraffers@`%` view hansik as
select `menudb`.`tbl_menu`.`menu_code`        AS `menu_code`,
       `menudb`.`tbl_menu`.`menu_name`        AS `menu_name`,
       `menudb`.`tbl_menu`.`menu_price`       AS `menu_price`,
       `menudb`.`tbl_menu`.`category_code`    AS `category_code`,
       `menudb`.`tbl_menu`.`orderable_status` AS `orderable_status`
from `menudb`.`tbl_menu`
where (`menudb`.`tbl_menu`.`category_code` = 4);

-- comment on column hansik.menu_code not supported: 메뉴코드

-- comment on column hansik.menu_name not supported: 메뉴명

-- comment on column hansik.menu_price not supported: 메뉴가격

-- comment on column hansik.category_code not supported: 카테고리코드

-- comment on column hansik.orderable_status not supported: 주문가능상태

